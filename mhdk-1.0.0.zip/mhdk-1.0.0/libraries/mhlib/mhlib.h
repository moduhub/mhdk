#ifndef _MHLIB_H_INCLUDED
#define _MHLIB_H_INCLUDED

#include <Arduino.h>

class MHLibClass {
	
	public:
	
		void initialize();
		
		void updateVariable(void);
	
	private:
  
		uint8_t dummy;
};

extern MHLibClass MHLib;

#endif
