
#include "MHLib.h"

MHLibClass SPI;

void MHLibClass::initialize() {
	
  
}

void MHLibClass::updateVariable() {
	
  
}

